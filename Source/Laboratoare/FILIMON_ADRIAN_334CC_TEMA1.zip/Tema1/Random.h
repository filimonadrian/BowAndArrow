# pragma once

#include <iostream>
#include <random>

float generateFloat(int rangeFrom, int rangeTo);
int generateInt(int rangeFrom, int rangeTo);